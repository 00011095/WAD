using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace GameStore.Pages.games
{
    public class CreateModel : PageModel
    {
        public GameInfo gameInfo = new GameInfo();
        public String errorMessage = "";
        public String succesMessage = "";
        public void OnGet()
        {
        }

        public void OnPost()
        {
            gameInfo.name = Request.Form["name"];
			gameInfo.genre = Request.Form["genre"];
			gameInfo.price = Request.Form["price"];
			gameInfo.studio = Request.Form["studio"];

            if (gameInfo.name.Length == 0 || gameInfo.genre.Length == 0 ||
				gameInfo.price.Length == 0 || gameInfo.studio.Length == 0)
            {
                errorMessage = "All field are required";
                return;
            }

            try
            {
				String connectionString = "Data Source=localhost;Initial Catalog=gamestore;Integrated Security=True";
				using (SqlConnection connection = new SqlConnection(connectionString))
				{
                    connection.Open();
                    String sql = "INSERT INTO games " +
                                 "(name, genre, price, studio) VALUES " +
                                 "(@name, @genre, @price, @studio);";

                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@name", gameInfo.name);
						command.Parameters.AddWithValue("@genre", gameInfo.genre);
						command.Parameters.AddWithValue("@price", gameInfo.price);
						command.Parameters.AddWithValue("@studio", gameInfo.studio);

                        command.ExecuteNonQuery();
					}
                }
			}

            catch (Exception ex)
            {
                errorMessage = ex.Message;
                return;
            }

            gameInfo.name = ""; gameInfo.genre = ""; gameInfo.price = ""; gameInfo.studio = "";
            succesMessage = "New game added";

            Response.Redirect("/games/index");
		}
    }
}
