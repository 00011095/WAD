using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace GameStore.Pages.games
{
    public class IndexModel : PageModel
    {

        public List<GameInfo> listGames = new List<GameInfo>();

        public void OnGet()
        {

            try
            {
                String connectionString = "Data Source=localhost;Initial Catalog=gamestore;Integrated Security=True";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {

                    connection.Open();
                    String sql = "SELECT * FROM games";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                GameInfo gameinfo = new GameInfo();
                                gameinfo.id = "" + reader.GetInt32(0);
                                gameinfo.name = reader.GetString(1);
                                gameinfo.genre = reader.GetString(2);
                                gameinfo.price = reader.GetString(3);
                                gameinfo.studio = reader.GetString(4);
                                gameinfo.created_at = reader.GetDateTime(5).ToString();

                                listGames.Add(gameinfo);

                            }
                        }
                    }

                }
            }
            catch (Exception ex) 
            {

            }
        }
    }

    public class GameInfo
    {
        public string id;
        public string name;
        public string genre;
        public string price;
        public string studio;
        public string created_at;
    }
}
