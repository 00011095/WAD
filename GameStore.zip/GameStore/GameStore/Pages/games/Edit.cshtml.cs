using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace GameStore.Pages.games
{
    public class EditModel : PageModel
    {

        public GameInfo gameInfo = new GameInfo();
        public String errorMessage = "";
        public String succesMessage = "";
        public void OnGet()
        {
            String id = Request.Query["id"];

            try
            {
				String connectionString = "Data Source=localhost;Initial Catalog=gamestore;Integrated Security=True";

				using (SqlConnection connection = new SqlConnection(connectionString))
				{

					connection.Open();
					String sql = "SELECT * FROM games WHERE id=@id";
					using (SqlCommand command = new SqlCommand(sql, connection))
					{
						command.Parameters.AddWithValue("@id", id);
						using (SqlDataReader reader = command.ExecuteReader())
						{
							if (reader.Read())
							{
								gameInfo.id = "" + reader.GetInt32(0);
								gameInfo.name = reader.GetString(1);
								gameInfo.genre = reader.GetString(2);
								gameInfo.price = reader.GetString(3);
								gameInfo.studio = reader.GetString(4);

							}
						}
					}

				}
			}

            catch(Exception ex) 
            {
                errorMessage = ex.Message;
            }
        }


        public void OnPost()
        {
			gameInfo.id = Request.Form["id"];
			gameInfo.name = Request.Form["name"];
			gameInfo.genre = Request.Form["genre"];
			gameInfo.price = Request.Form["price"];
			gameInfo.studio = Request.Form["studio"];

			if (gameInfo.name.Length == 0 || gameInfo.genre.Length == 0 ||
					gameInfo.price.Length == 0 || gameInfo.studio.Length == 0)
			{
				errorMessage = "All field are required";
				return;
			}


			try
			{
				String connectionString = "Data Source=localhost;Initial Catalog=gamestore;Integrated Security=True";
				using (SqlConnection connection = new SqlConnection(connectionString))
				{
					connection.Open();
					String sql = "UPDATE games " +
								 "SET name=@name, genre=@genre, price=@price, studio=@studio" +
								 "WHERE id=@id";

					using (SqlCommand command = new SqlCommand(sql, connection))
					{
						command.Parameters.AddWithValue("@name", gameInfo.name);
						command.Parameters.AddWithValue("@genre", gameInfo.genre);
						command.Parameters.AddWithValue("@price", gameInfo.price);
						command.Parameters.AddWithValue("@studio", gameInfo.studio);
						command.Parameters.AddWithValue("@id", gameInfo.id);

						command.ExecuteNonQuery();
					}
				}
			}

			catch(Exception ex )
			{
				errorMessage= ex.Message;
				return;
			}

			Response.Redirect("/games/Index");
		}

		
}


}
